%startup - this script sets up the CATA/SIMULINK global simulation parameters/memory and opens the GUI figure 
%       which calls other intialization functions
%
%  Inputs:
%    (none) 
%
%  Outputs:
%    (none)
%

%  AFRL/VACA
%  December 2000 - Created and Debugged - RAS
%  May 2001 - moved globals to separate script - RAS

% intialize global variables
InitializeGlobals;

