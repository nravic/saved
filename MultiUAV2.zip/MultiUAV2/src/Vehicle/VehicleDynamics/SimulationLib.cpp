// used to build the library
#include "VehicleSimulation.h"

#ifdef GIMME_A_DUMMY_INSTANCE_OF_THE_VEHICLE_SIMULATION
  CVehicleSimulation<VAL_DOUBLE_t,V_PDOUBLE_t,V_DOUBLE_t,double>
   CVEHICLESIMULATION_DUMMY_NEEDED_TO_FORCE_COMPILER_TO_RECOGNIZE_THIS_CLASS;
#endif
